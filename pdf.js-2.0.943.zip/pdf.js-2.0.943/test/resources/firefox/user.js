// Disable the default browser test.
user_pref('browser.shell.checkDefaultBrowser', false);
