function f1() {
}
function f2() {
 return 1;
}
function f3() {
 var i = 0;
 throw "test";
}
function f4() {
 var i = 0;
}

