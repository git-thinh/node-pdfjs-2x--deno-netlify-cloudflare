import { Test } from 'import-alias';
import { Test2 } from './non-alias';
export { Test3 } from 'import-alias';
var Imp = require('import-alias');
var Imp2 = require('./non-alias');
